function holajo(){
    alert("Hello Narcis");
    console.log("traceado")
}